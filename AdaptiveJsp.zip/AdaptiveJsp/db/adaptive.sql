-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 18, 2019 at 01:46 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adaptive`
--

-- --------------------------------------------------------

--
-- Table structure for table `mark`
--

CREATE TABLE IF NOT EXISTS `mark` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `mark` int(50) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `mark`
--

INSERT INTO `mark` (`sno`, `name`, `contact_no`, `mark`) VALUES
(1, 'niki', '9748462346', 10),
(2, 'niki', '9748462346', 7),
(3, 'niki', '9748462346', 9),
(4, 'niki', '9748462346', 7),
(5, 'niki', '9748462346', 10),
(6, 'niki', '9748462346', 8),
(7, 'niki', '9748462346', 1),
(8, 'dinesh', '6457362753', 8),
(9, 'dinesh', '6457362753', 1),
(10, 'ranju', '9347836423', 2),
(11, 'kk', '9898989898', 3),
(12, 'n', '7878787878', 0),
(13, 'n', '7878787878', 0),
(14, 'aarthy', '9696969696', 1),
(15, 'aarthy', '9696969696', 6),
(16, 'kk', '9898989898', 0),
(17, 'kanikii', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`sno`, `name`, `username`, `password`, `contact_no`) VALUES
(1, 'niki', 'niki', '123', '9748462346'),
(2, 'kani', 'kani', '123', '3486543241'),
(3, 'dm', 'dm', 'dm', '6365423533'),
(4, 'dm', 'dm', 'dm', '6365423533'),
(5, 'dinesh', 'dinesh', 'dinesh', '6457362753'),
(6, 'ranju', 'ranju', 'ranju', '9347836423'),
(7, 'kk', 'kk', 'kk', '9898989898'),
(8, 'kk', 'kk', 'kk', '9898989898'),
(9, 'n', 'n', 'n', '7878787878'),
(10, 'aarthy', 'aarthy', '1', '9696969696'),
(11, 'ka', 'ka', 'ka', '123'),
(12, 'kanikii', 'kanikii', 'kanikii', '123'),
(13, '1', '1', '1', '123'),
(14, 'l', 'l', 'l', '9595959595');
